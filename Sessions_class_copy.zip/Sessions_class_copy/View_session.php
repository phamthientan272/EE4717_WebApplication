
<?php 

Session_start();

echo $_SESSION['Username'];

?>