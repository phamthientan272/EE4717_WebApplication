
<?php 

echo $_COOKIE['Username'];

?>