
<?php 

setcookie('Username','alex',time()+10);

?>