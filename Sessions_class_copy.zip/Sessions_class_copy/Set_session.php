
<?php 

Session_start();

$_SESSION['Username']= 'alex';

?>