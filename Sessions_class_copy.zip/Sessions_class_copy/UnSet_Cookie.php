
<?php 

setcookie('Username','alex',time()+10);
setcookie('Username','alex',time()-10);

?>