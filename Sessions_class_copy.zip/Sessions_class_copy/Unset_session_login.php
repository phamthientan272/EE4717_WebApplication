
<?php 

Session_start();

unset($_SESSION['Username']);

?>